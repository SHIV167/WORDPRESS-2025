Step 1: Create Plugin Folder & Main File
Navigate to the wp-content/plugins/ directory.
Create a new folder for your plugin, e.g., my-custom-plugin.
Inside this folder, create a main file named my-custom-plugin.php.
Step 2: Add Plugin Header
Open my-custom-plugin.php and add the following header:

php
Copy
Edit
<?php
/**
 * Plugin Name: My Custom Plugin
 * Plugin URI: https://example.com
 * Description: A boilerplate custom plugin for WordPress.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: my-custom-plugin
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define plugin constants
define('MY_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MY_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include necessary files
require_once MY_PLUGIN_PATH . 'includes/class-my-plugin.php';

// Initialize the plugin
function my_custom_plugin_init() {
    new My_Custom_Plugin();
}
add_action('plugins_loaded', 'my_custom_plugin_init');
Step 3: Create an Includes Folder
Inside the my-custom-plugin folder, create a new folder named includes.

Inside includes/, create a new file: class-my-plugin.php.

Step 4: Create Plugin Class
Open includes/class-my-plugin.php and add:

php
Copy
Edit
<?php
if (!defined('ABSPATH')) {
    exit;
}

class My_Custom_Plugin {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    // Add menu in WordPress Admin
    public function add_admin_menu() {
        add_menu_page(
            'My Plugin Settings', 
            'My Plugin', 
            'manage_options', 
            'my-custom-plugin', 
            [$this, 'plugin_settings_page'],
            'dashicons-admin-generic', 
            90
        );
    }

    // Enqueue styles & scripts
    public function enqueue_scripts() {
        wp_enqueue_style('my-plugin-style', MY_PLUGIN_URL . 'assets/style.css');
        wp_enqueue_script('my-plugin-script', MY_PLUGIN_URL . 'assets/script.js', ['jquery'], false, true);
    }

    // Plugin settings page content
    public function plugin_settings_page() {
        echo '<div class="wrap"><h1>My Custom Plugin Settings</h1><p>Configure your plugin here.</p></div>';
    }
}
Step 5: Create Assets Folder
Inside my-custom-plugin, create a folder named assets, and inside it:

style.css

css
Copy
Edit
/* Plugin Admin Styles */
.wrap h1 {
    color: #0073aa;
}
script.js

js
Copy
Edit
(function($) {
    $(document).ready(function() {
        console.log("My Custom Plugin Loaded");
    });
})(jQuery);
