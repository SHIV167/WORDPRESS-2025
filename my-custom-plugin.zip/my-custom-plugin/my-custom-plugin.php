<?php
/**
 * Plugin Name: My Custom Plugin
 * Plugin URI: https://example.com
 * Description: A boilerplate custom plugin for WordPress.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: my-custom-plugin
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define plugin constants
define('MY_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MY_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include necessary files
require_once MY_PLUGIN_PATH . 'includes/class-my-plugin.php';

// Initialize the plugin
function my_custom_plugin_init() {
    new My_Custom_Plugin();
}
add_action('plugins_loaded', 'my_custom_plugin_init');
