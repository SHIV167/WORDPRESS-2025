<?php
if (!defined('ABSPATH')) {
    exit;
}

class My_Custom_Plugin {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    // Add menu in WordPress Admin
    public function add_admin_menu() {
        add_menu_page(
            'My Plugin Settings', 
            'My Plugin', 
            'manage_options', 
            'my-custom-plugin', 
            [$this, 'plugin_settings_page'],
            'dashicons-admin-generic', 
            90
        );
    }

    // Enqueue styles & scripts
    public function enqueue_scripts() {
        wp_enqueue_style('my-plugin-style', MY_PLUGIN_URL . 'assets/style.css');
        wp_enqueue_script('my-plugin-script', MY_PLUGIN_URL . 'assets/script.js', ['jquery'], false, true);
    }

    // Plugin settings page content
    public function plugin_settings_page() {
        echo '<div class="wrap"><h1>My Custom Plugin Settings</h1><p>Configure your plugin here.</p></div>';
    }
}
