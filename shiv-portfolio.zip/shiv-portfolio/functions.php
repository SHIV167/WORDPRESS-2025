<?php
function shiv_portfolio_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    
    // Register menus
    register_nav_menus(array(
        'primary-menu' => __('Primary Menu', 'shiv-portfolio'),
        'footer-menu-1' => __('Footer Menu 1', 'shiv-portfolio'),
        'footer-menu-2' => __('Footer Menu 2', 'shiv-portfolio')
    ));
}
add_action('after_setup_theme', 'shiv_portfolio_setup');

function shiv_portfolio_scripts() {
    // Enqueue styles
    wp_enqueue_style('shiv-portfolio-style', get_stylesheet_uri());
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css');
    
    // Enqueue additional stylesheets from css folder
    wp_enqueue_style('shiv-portfolio-styles', get_template_directory_uri() . '/css/style.css');
    wp_enqueue_style('shiv-portfolio-animation', get_template_directory_uri() . '/css/animation.css');
    wp_enqueue_style('shiv-portfolio-popup', get_template_directory_uri() . '/css/popup.css');
    
    // Enqueue scripts
    wp_enqueue_script('shiv-portfolio-script', get_template_directory_uri() . '/js/script.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'shiv_portfolio_scripts');

// Customizer settings
function shiv_portfolio_customize_register($wp_customize) {
    // Footer Address
    $wp_customize->add_section('footer_settings', array(
        'title' => __('Footer Settings', 'shiv-portfolio'),
        'priority' => 120,
    ));
    
    $wp_customize->add_setting('footer_address', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('footer_address', array(
        'label' => __('Footer Address', 'shiv-portfolio'),
        'section' => 'footer_settings',
        'type' => 'text',
    ));
    
    // Social Profile Link
    $wp_customize->add_setting('social_profile_link', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('social_profile_link', array(
        'label' => __('Social Profile Link', 'shiv-portfolio'),
        'section' => 'footer_settings',
        'type' => 'url',
    ));
    
    // Copyright Text
    $wp_customize->add_setting('copyright_text', array(
        'default' => '© ' . date('Y') . ' ' . get_bloginfo('name'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('copyright_text', array(
        'label' => __('Copyright Text', 'shiv-portfolio'),
        'section' => 'footer_settings',
        'type' => 'text',
    ));
}
add_action('customize_register', 'shiv_portfolio_customize_register');