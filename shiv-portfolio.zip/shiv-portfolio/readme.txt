Here's the new folder structure for your theme:
Copyshiv-portfolio/
├── style.css (contains only theme information)
├── index.php
├── header.php
├── footer.php
├── functions.php
├── screenshot.png
├── css/
│   ├── style.css (main styles)
│   ├── animation.css
│   └── popup.css
├── js/
│   └── script.js
└── images/
    └── your-images-here
Key changes made:

Created a separate css folder for organizing stylesheets
Split the CSS into three files:

style.css (main styles)
animation.css (animation-related styles)
popup.css (popup-specific styles)


Updated functions.php to properly enqueue all stylesheets
Kept the main style.css in the theme root (required by WordPress) with only theme information
Moved all actual styles to the css folder

To implement these changes:

Create a css folder in your theme directory
Move the previous CSS content into the appropriate files in the css folder
Replace the root style.css with the minimal version containing only theme information
Update functions.php with the new enqueue functions
Make sure all file paths are correct

Remember to:

Keep the theme information in the root style.css file
Maintain proper file permissions (usually 644 for files)
Clear your WordPress cache after making these changes