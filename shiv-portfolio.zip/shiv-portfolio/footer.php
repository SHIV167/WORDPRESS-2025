<div class="wave-container">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#ffc0cb" fill-opacity="1"
            d="M0,160L48,160C96,160,192,160,288,170.7C384,181,480,203,576,181.3C672,160,768,96,864,74.7C960,53,1056,75,1152,112C1248,149,1344,203,1392,229.3L1440,256L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z">
        </path>
    </svg>
</div>
<footer class="container">
    <div class="sectionone">
        <h3><?php bloginfo('name'); ?></h3>
        <p><?php bloginfo('description'); ?></p>
        <?php if(get_theme_mod('footer_address')): ?>
        <p><?php echo esc_html(get_theme_mod('footer_address')); ?></p>
        <?php endif; ?>
    </div>
    <div class="sectiontwo">
        <h3><?php esc_html_e('About Link', 'shiv-portfolio'); ?></h3>
        <?php
            wp_nav_menu(array(
                'theme_location' => 'footer-menu-1',
                'container' => false,
                'menu_class' => 'navmenufoot',
            ));
            ?>
    </div>
    <div class="sectionthree">
        <h3><?php esc_html_e('About Link', 'shiv-portfolio'); ?></h3>
        <?php
            wp_nav_menu(array(
                'theme_location' => 'footer-menu-2',
                'container' => false,
                'menu_class' => 'navmenus',
            ));
            ?>
    </div>
    <div class="sectionfour">
        <h3><?php esc_html_e('Social Media', 'shiv-portfolio'); ?></h3>
        <ul class="navdash">
            <?php if(get_theme_mod('social_profile_link')): ?>
            <li class="menuitems"><a href="<?php echo esc_url(get_theme_mod('social_profile_link')); ?>"><i
                        class="fa-solid fa-user"></i></a></li>
            <?php endif; ?>
            <li class="menuitems"><i class="fa-solid fa-cart-shopping"></i></li>
            <li class="menuitems"><i class="fa-solid fa-heart"></i></li>
        </ul>
    </div>
    <hr>
    <div class="copyright">
        <p><?php echo esc_html(get_theme_mod('copyright_text', '© ' . date('Y') . ' ' . get_bloginfo('name'))); ?></p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>

</html>