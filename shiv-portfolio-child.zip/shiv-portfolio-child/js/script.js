const menuBtn = document.querySelector(".menu-btn");
const menu = document.querySelector(".menu");

menuBtn.addEventListener("click", () => {
  menu.classList.toggle("active");
  menuBtn.classList.toggle("active");
});

// MENU ACTIVE BORDER ANIMATION SELECTOR
// Select all list items
const listItems = document.querySelectorAll(".items>.list");
//console.log(listItems);

// Add click event listener to each list item
listItems.forEach((item) => {
  item.addEventListener("click", () => {
    // Remove active class from all items
    listItems.forEach((li) => li.classList.remove("active"));

    // Add active class to clicked item
    item.classList.add("active");
    //console.log(listItems);
  });
});

// POPUP STARTS

let pop = document.querySelector("#popup");
let popup = document.querySelector(".popup-content");
let closepop = document.querySelector("button.close");

pop.addEventListener("click", () => {
  popup.classList.add("open");
});
closepop.addEventListener("click", () => {
  popup.classList.remove("open");
});

// Method 1: Using for...of loop
// const listItems = document.querySelectorAll(".list");
// for (const item of listItems) {
//   item.addEventListener("click", () => {
//     // Remove active class using for...of
//     for (const li of listItems) {
//       li.classList.remove("active");
//     }
//     item.classList.add("active");
//   });
// }

// Method 2: Using traditional for loop
/*
const listItems = document.querySelectorAll('.list');
for (let i = 0; i < listItems.length; i++) {
    listItems[i].addEventListener('click', () => {
        for (let j = 0; j < listItems.length; j++) {
            listItems[j].classList.remove('active');
        }
        listItems[i].classList.add('active');
    });
}
*/

// Method 3: Using Array.from with map
/*
const listItems = document.querySelectorAll('.list');
Array.from(listItems).map(item => {
    item.addEventListener('click', () => {
        Array.from(listItems).map(li => li.classList.remove('active'));
        item.classList.add('active');
    });
});
*/

// Method 4: Most concise solution using spread operator
/*
const listItems = document.querySelectorAll('.list');
[...listItems].forEach(item => {
    item.addEventListener('click', () => {
        [...listItems].forEach(li => li.classList.remove('active'));
        item.classList.add('active');
    });
});
*/
