<?php get_header(); ?>





<!-- HERO BANNER SECTION STARTS HERE -->
<section class="hero">
    <div class="left">
        <h1 style="color: pink;">SHIV KUMAR JHA</h1>
        <h4 style="color: #ffc0cb;;">WEB DEVELOPMENT</h4>
        <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
            Nam placeat
            modi doloremque itaque vel possimus eveniet totam
            consectetur eius
            temporibus accusantium saepe esse magni atque minima numquam
            repudiandae deserunt autem minus quod aliquid, ipsam, fugiat
            delectus
            sed? Vitae tempora minima dolores explicabo quia quis
            voluptas
            reprehenderit ullam ipsam velit maiores vel laboriosam
            natus, adipisci
            quasi nemo necessitatibus. Commodi libero qui praesentium a
            non magni
        </p>
        <span><button id="popup">Click Me I m a Popup</button></span>
    </div>
    </div>
</section>


<div class="containerpop">
    <div class="popup-content">
        <img src="<?php echo esc_url(get_theme_file_uri('images/ok-1976099_640.png')); ?>"
            style="width:150px;height: 150px;margin-top: -80px;align-items: center;" alt>
        <!-- <div class="cross close">X</div> -->
        <h2>Popup</h2>
        <p>
            Thanks Your details has been submitted successfully. We
            will
            contact you soon.
        </p>
        <button class="close">OK</button>
    </div>

    <!-- HERO BANNER SECTION ENDS HERE -->

    <!-- VIDEO ABOUT SECTION STARTS HERE -->
    <section class="vdo">
        <h3 class="main-title">ABOUT US</h3>
        <div class="vdo-content">
            <div class="firsthalf">
                <video src="<?php echo esc_url(get_theme_file_uri('images/Animated_Background.mp4')); ?>" loop autoplay
                    muted></video>
                <h2>BEST VIDEOS HERE</h2>
            </div>
            <div class="secondhalf">
                <h3>HEADING</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Nihil rem nobis quaerat nam suscipit vitae laboriosam
                    dignissimos enim
                    ab eaque, adipisci pariatur! Dolorum accusantium
                    provident aperiam
                    obcaecati rerum eius iusto id optio veritatis rem
                    reiciendis
                    voluptates excepturi illum corporis voluptatibus quidem
                    suscipit
                    nostrum expedita, libero architecto consequuntur nihil.
                    Corporis
                    dicta quos dolore tenetur necessitatibus obcaecati quod
                    omnis corrupti
                    autem adipisci.
                </p>
            </div>
        </div>
    </section>
    <!-- VIDEO ABOUT SECTION ENDS HERE -->

    <!-- PROMOTION BLOCK SECTION STARTS HERE -->
    <section class="ben">
        <div class="details">
            <i class="fa-solid fa-cart-shopping"></i>
            <div class="content">
                <h3>Offer and gifts</h3>
                <p>valid on all</p>
            </div>

        </div>
        <div class="details">
            <i class="fa-solid fa-cart-shopping"></i>
            <div class="content">
                <h3>Offer and gifts</h3>
                <p>valid on all</p>
            </div>

        </div>
        <div class="details">
            <i class="fa-solid fa-cart-shopping"></i>
            <div class="content">
                <h3>Offer and gifts</h3>
                <p>valid on all</p>
            </div>

        </div>
        <div class="details">
            <i class="fa-solid fa-cart-shopping"></i>
            <div class="content">
                <h3>Offer and gifts</h3>
                <p>valid on all</p>
            </div>

        </div>

    </section>
    <!-- PROMOTION BLOCK SECTION ENDS HERE -->

    <!-- CUSTOMER REVIEW STARTS HERE -->
    <section class="review">
        <div class="custom">
            <div class="contents">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Culpa natus numquam eveniet molestiae expedita quos nisi
                    et assumenda laudantium ducimus aspernatur, recusandae
                    neque, eum atque necessitatibus fugiat maxime similique.
                    Id quis earum hic quos nulla, harum eligendi dolore
                    ipsam recusandae.</p>
            </div>
            <div class="user">
                <img src="<?php echo esc_url(get_theme_file_uri('images/back.jpg')); ?>" alt width="70px" height="70px"
                    style="border-radius: 50%;" />
                <div class="info">
                    <h3>James</h3>
                    <p>Happy Customer</p>
                </div>
                <i style="font-size:24px" class="fa">&#xf10e;</i>
            </div>
        </div>
        <div class="custom">
            <div class="contents">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Culpa natus numquam eveniet molestiae expedita quos nisi
                    et assumenda laudantium ducimus aspernatur, recusandae
                    neque, eum atque necessitatibus fugiat maxime similique.
                    Id quis earum hic quos nulla, harum eligendi dolore
                    ipsam recusandae.</p>
            </div>
            <div class="user">
                <img src="<?php echo esc_url(get_theme_file_uri('images/back.jpg')); ?>" alt width="70px" height="70px"
                    style="border-radius: 50%;" />
                <div class="info">
                    <h3>James</h3>
                    <p>Happy Customer</p>
                </div>
                <i style="font-size:24px" class="fa">&#xf10e;</i>
            </div>
        </div>
        <div class="custom">
            <div class="contents">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Culpa natus numquam eveniet molestiae expedita quos nisi
                    et assumenda laudantium ducimus aspernatur, recusandae
                    neque, eum atque necessitatibus fugiat maxime similique.
                    Id quis earum hic quos nulla, harum eligendi dolore
                    ipsam recusandae.</p>
            </div>
            <div class="user">
                <img src="<?php echo esc_url(get_theme_file_uri('images/back.jpg')); ?>" alt width="70px" height="70px"
                    style="border-radius: 50%;" />
                <div class="info">
                    <h3>James</h3>
                    <p>Happy Customer</p>
                </div>
                <i style="font-size:24px" class="fa">&#xf10e;</i>
            </div>
        </div>
    </section>
    <!-- CUSTOMER REVIEW ENDS HERE -->

    <?php get_footer(); ?>